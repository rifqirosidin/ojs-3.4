# acron
Acron (cron-less scheduled task execution) plugin for OJS, OMP, and OPS

This plugin is included in OJS, OMP, and OPS; there is no need to install or update it separately.
