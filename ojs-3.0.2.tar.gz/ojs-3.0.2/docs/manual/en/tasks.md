# Tasks

Tasks provide quick access to updates and outstanding responsibilities within the editorial workflow.

You can click the Tasks link on the main navigation menu to view any pending tasks. You can delete Tasks when they are no longer useful.
